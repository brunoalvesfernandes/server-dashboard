
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const fs = require('fs');
const { exec } = require('child_process');

const app = express();
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({secret:'hytale',resave:false,saveUninitialized:false}));
app.use(express.static('public'));

const users = JSON.parse(fs.readFileSync('users.json'));

app.post('/login', async (req,res)=>{
 const {user,pass} = req.body;
 if(!users[user]) return res.sendStatus(401);
 if(await bcrypt.compare(pass, users[user])){
   req.session.user = user;
   return res.redirect('/panel.html');
 }
 res.sendStatus(401);
});

function auth(req,res,next){
 if(!req.session.user) return res.redirect('/');
 next();
}

app.get('/status', auth, (req,res)=>{
 exec('systemctl is-active hytale', (e, out)=>res.json({status: out.trim()}));
});

app.post('/action', auth, (req,res)=>{
 exec(`systemctl ${req.body.cmd} hytale`, ()=>res.sendStatus(200));
});

app.get('/logs', auth, (req,res)=>{
 exec('journalctl -u hytale -n 100', (e,out)=>res.send(out));
});

app.listen(3007, ()=>console.log('Panel on 3007'));
